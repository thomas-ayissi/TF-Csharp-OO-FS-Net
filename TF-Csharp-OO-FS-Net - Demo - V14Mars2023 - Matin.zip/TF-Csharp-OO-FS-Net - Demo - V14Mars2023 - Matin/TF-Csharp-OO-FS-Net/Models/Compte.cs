﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TF_Csharp_OO_FS_Net.Models
{
    public abstract class Compte
    {
        #region Props

        public string Numero { get; set; }

        public double Solde { get; private set; } // Lecture Seule

        public Personne Titulaire { get; set; }


        #endregion



        public static double operator +(double solde, Compte compte2)
        {

            // Equivalent du premier ternaire ci dessous

            //double valeur;

            //if (compte1.Solde > 0)
            //{
            //    valeur= compte1.Solde;
            //}
            //else
            //{
            //    valeur = 0;
            //}




            double valeur2 = compte2.Solde > 0 ? compte2.Solde : 0;
            return solde + valeur2;
        }


        #region Methodes
        public virtual void Retrait(double montant)
        {
            Retrait(montant, 0);
        }
        public void Retrait(double montant,double ligneDeCredit)
        {
            if (montant > 0 && Solde - montant > -ligneDeCredit)
                Solde -= montant;
        }

        public void Depot(double montant)
        {
            if(montant > 0) 
                Solde += montant;
        }

        protected abstract double CalculInteret();
        public void AppliquerInteret()
        {
            Solde += CalculInteret();
        }

        #endregion
    }
}
