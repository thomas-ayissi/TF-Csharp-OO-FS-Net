﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TF_Csharp_OO_FS_Net.Models
{
    public class Epargne : Compte
    {
        #region Props

        public DateTime DateDernierRetrait { get; set; }


        #endregion


        #region Methodes

        void Retrait(double montant)
        {
            double soldePrecedent = Solde;
            base.Retrait(montant);
            if (soldePrecedent > Solde)
                DateDernierRetrait = DateTime.Now;
        }
        protected override double CalculInteret()
        {
            return Solde * .045;
        }

        #endregion
    }
}
